import java.sql.*;
class First {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            //creating a connection
            String url="jdbc:mysql://localhost:3306/youtube";
            String username="root";
            String password="12345";

            Connection con = DriverManager.getConnection(url,username,password);
            // create a query
            String q="create table data(tId int(20) primary key auto_increment, " +
                    "Name varchar(200) not null, City varchar(200))";

            // create Statement

            Statement stmt=con.createStatement();
            stmt.executeUpdate(q);
            System.out.println("table created");
            con.close();

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}