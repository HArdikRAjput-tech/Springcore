package com.springcore.standalone.collections;

public class Test {

}
