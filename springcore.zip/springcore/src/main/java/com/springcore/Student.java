package com.springcore;

public class Student {
	
	private int studentid;
	private String stuentname;
	private String studentaddress;
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStuentname() {
		return stuentname;
	}
	public void setStuentname(String stuentname) {
		this.stuentname = stuentname;
	}
	public String getStudentaddress() {
		return studentaddress;
	}
	public void setStudentaddress(String studentaddress) {
		this.studentaddress = studentaddress;
	}
	public Student(int studentid, String stuentname, String studentaddress) {
		super();
		this.studentid = studentid;
		this.stuentname = stuentname;
		this.studentaddress = studentaddress;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", stuentname=" + stuentname + ", studentaddress=" + studentaddress
				+ "]";
	}
	
	

}
