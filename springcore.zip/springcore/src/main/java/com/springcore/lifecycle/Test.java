package com.springcore.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/springcore/lifecycle/config.xml");
		
		//Life life=(Life)context.getBean("life");
		//System.out.println(life);
		// registering shutdown hook
		context.registerShutdownHook();
		
		Example example=(Example)context.getBean("exmaple");
		
		System.out.println(example);
	}
	@PostConstruct
	public void start() {
		System.out.println("This is starting");
	}
	
	public void end() {
		System.out.println("This is ending");
	}

}
