package com.springcore.lifecycle;

public class Life {
	
	private double Years;

	public double getYears() {
		return Years;
	}

	public void setYears(double years) {
		System.out.println("Setting years");
		this.Years = years;
	}

	public Life() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Life [Years=" + Years + "]";
	}
	
	public void init() {
		System.out.println("Inside init method");
	}
	
	public void destroy() {
		System.out.println("Inside destroy method");
	}
}
